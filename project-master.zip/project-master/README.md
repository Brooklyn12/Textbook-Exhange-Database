#README  
you can use the django api admin framework on web (localhost:8000/admin) to easily edit tables  
(might have to create a super user to access)  
"py manage.py createsuperuser"  
  
run in virtual env  
make sure to migrate  
to check if anything needs to migrate:  
"py manage.py makemigrations"  
(if above doesn't detect any changes, try "py manage.py makemigrations api"  
make migration:  
"py manage.py migrate"  
to run the api:  
"py manage.py runserver"  
  
Issues:  
  ~~can't update table data through postman?~~ nvm im an idiot   
  
  
TODO:  
Finish making tables  
Make the post/delete/get/put functions in views.py  
make all the url endpoints  
...?
